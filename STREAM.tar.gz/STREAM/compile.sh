sizekb="1024 4096 8192 16384 32768"
sizemb="65536 131072"
for cursize in $sizekb
do
    echo $cursize
    riscv64-unknown-linux-gnu-gcc  -fopenmp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=5000 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.riscv -static
done
for cursize in $sizemb
do
    echo $cursize
    riscv64-unknown-linux-gnu-gcc  -fopenmp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=5000 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.riscv -static
done

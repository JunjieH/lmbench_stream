sizekb="1024 4096 8192 16384 32768"
sizemb="65536 131072"
CC="/opt/tiger/riscv-toolchain/bin/clang"

for cursize in $sizekb
do
    echo $cursize
    $CC -march=rv64imafdcv_zba_zbb_zbc_zbs_zicond_zicbom_zicbop_zicboz_zicsr_zifencei_zihintpause_zawrs_zfa_zacas -fopenmp=libgomp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=10000 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.rv -static
done
for cursize in $sizemb
do
    echo $cursize
    $CC -march=rv64imafdcv_zba_zbb_zbc_zbs_zicond_zicbom_zicbop_zicboz_zicsr_zifencei_zihintpause_zawrs_zfa_zacas -fopenmp=libgomp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=500 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.rv -static
done

../523.cpuxalan_r.origin.elf -v t5.xml xalanc.xsl

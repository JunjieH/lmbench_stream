#include "bench.h"

int
main()
{
	printf("%.8f\n", l_overhead());
	return (0);
}

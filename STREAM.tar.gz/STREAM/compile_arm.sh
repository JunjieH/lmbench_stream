sizekb="1024 4096 8192 16384 32768"
sizemb="65536 131072"
CC="/usr/local/bin/clang"

for cursize in $sizekb
do
    echo $cursize
    $CC -march=armv9-a+nosve+nosimd -Xclang -target-feature -Xclang +disable-ldp -Xclang -target-feature -Xclang +disable-stp -fno-vectorize -fno-slp-vectorize -fopenmp=libgomp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=10000 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.arm -static
done
for cursize in $sizemb
do
    echo $cursize
    $CC -march=armv9-a+nosve+nosimd -Xclang -target-feature -Xclang +disable-ldp -Xclang -target-feature -Xclang +disable-stp -fno-vectorize -fno-slp-vectorize -fopenmp=libgomp -O3 -DSTREAM_ARRAY_SIZE=$cursize  -DNTIMES=500 -DOFFSET=0 -DSTREAM_TYPE=double -fno-PIC   stream.c -o stream_static_${cursize}.arm -static
done
